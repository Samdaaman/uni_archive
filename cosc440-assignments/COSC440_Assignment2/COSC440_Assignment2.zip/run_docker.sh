#!/bin/bash

docker build --rm -t cosc440-sho116 .
docker run -it cosc440-sho116